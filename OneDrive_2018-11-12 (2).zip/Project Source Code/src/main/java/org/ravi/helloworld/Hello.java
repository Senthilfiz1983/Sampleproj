package org.ravi.helloworld;

public class Hello {
	
	public String displayHelloMessage(String message){
		message = "hi";
		return message;
	}

}
